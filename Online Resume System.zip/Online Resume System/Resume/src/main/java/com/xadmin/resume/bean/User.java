package com.xadmin.resume.bean;


public class User {
	protected int id;
	protected String fname;
	protected String mname;
	protected String lname;
	protected String address;
	protected String dob;
	protected String gender;
	protected String marital;
	protected String phone;
	protected String email;
	protected String qualification;
	protected String institute;
	protected String yog;
	protected String pemp;
	protected String pdes;
	protected String cemp;
	protected String cdes;
	protected String totexp;
	protected String skills;
	public User() {
	}
	public User(int id, String fname, String mname, String lname, String address, String dob, String gender,
			String marital, String phone, String email, String qualification, String institute, String yog, String pemp,
			String pdes, String cemp, String cdes, String totexp, String skills) {
		super();
		this.id = id;
		this.fname = fname;
		this.mname = mname;
		this.lname = lname;
		this.address = address;
		this.dob = dob;
		this.gender = gender;
		this.marital = marital;
		this.phone = phone;
		this.email = email;
		this.qualification = qualification;
		this.institute = institute;
		this.yog = yog;
		this.pemp = pemp;
		this.pdes = pdes;
		this.cemp = cemp;
		this.cdes = cdes;
		this.totexp = totexp;
		this.skills = skills;
	}
	public User(String fname, String mname, String lname, String address, String dob, String gender, String marital,
			String phone, String email,String qualification,String institute) {
		super();
		this.fname = fname;
		this.mname = mname;
		this.lname = lname;
		this.address = address;
		this.dob = dob;
		this.gender = gender;
		this.marital = marital;
		this.phone = phone;
		this.email = email;
		this.qualification = qualification;
		this.institute = institute;
	
	}
	public User(String fname, String mname, String lname) {
		super();
		this.fname = fname;
		this.mname = mname;
		this.lname = lname;
	}
	
	public User(String fname, String mname) {
		super();
		this.fname = fname;
		this.mname = mname;
		
	}
	public User(String fname, String mname, String lname, String address, String dob, String gender, String marital,
			String phone, String email, String qualification, String institute, String yog, String pemp, String pdes,
			String cemp, String cdes, String totexp, String skills) {
		super();
		this.fname = fname;
		this.mname = mname;
		this.lname = lname;
		this.address = address;
		this.dob = dob;
		this.gender = gender;
		this.marital = marital;
		this.phone = phone;
		this.email = email;
		this.qualification = qualification;
		this.institute = institute;
		this.yog = yog;
		this.pemp = pemp;
		this.pdes = pdes;
		this.cemp = cemp;
		this.cdes = cdes;
		this.totexp = totexp;
		this.skills = skills;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMarital() {
		return marital;
	}
	public void setMarital(String marital) {
		this.marital = marital;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public String getInstitute() {
		return institute;
	}
	public void setInstitute(String institute) {
		this.institute = institute;
	}
	public String getYog() {
		return yog;
	}
	public void setYog(String yog) {
		this.yog = yog;
	}
	public String getPemp() {
		return pemp;
	}
	public void setPemp(String pemp) {
		this.pemp = pemp;
	}
	public String getPdes() {
		return pdes;
	}
	public void setPdes(String pdes) {
		this.pdes = pdes;
	}
	public String getCemp() {
		return cemp;
	}
	public void setCemp(String cemp) {
		this.cemp = cemp;
	}
	public String getCdes() {
		return cdes;
	}
	public void setCdes(String cdes) {
		this.cdes = cdes;
	}
	public String getTotexp() {
		return totexp;
	}
	public void setTotexp(String totexp) {
		this.totexp = totexp;
	}
	public String getSkills() {
		return skills;
	}
	public void setSkills(String skills) {
		this.skills = skills;
	}
}
	
	