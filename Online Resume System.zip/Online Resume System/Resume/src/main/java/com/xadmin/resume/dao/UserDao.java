package com.xadmin.resume.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.xadmin.resume.bean.User;

public class UserDao {
	private String dburl = "jdbc:mysql://localhost:3306/userdb";
	private String dbUname = "root";
	private String dbPassword = "root";
	private String dbDriver="com.mysql.cj.jdbc.Driver";

	/*private static final String INSERT_USERS_SQL = "INSERT INTO users" + "  (name, email, country) VALUES "
			+ "(?, ?, ?);";*/
	private static final String SELECT_USER_BY_ID = "select id,name,email,country from users ORDER BY ID DESC LIMIT 1 ";
	private static final String SELECT_ALL_USERS = "select * from users ORDER BY ID DESC LIMIT 1";
	private static final String DELETE_USERS_SQL = "delete from users where id = ?;";
	private static final String UPDATE_USERS_SQL = "update users set fname = ?,mname= ?, lname =?, address=?,dob=?,gender=?,marital=?,phone=?,email=?,qualification=?,institute=?,yog=?,pemp=?,pdes=?,cemp=?,cdes=?,totexp=?,skills=? where id = ?;";
	private static final String SELECT_ALL_JOBS = "select * from member";
	private static final String SELECT_ALL_RESUMES = "select * from users";
	
	public void loadDriver(String dbDriver)
	{
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Connection getConnection()
	{
		Connection con=null;
		try {
			con=DriverManager.getConnection(dburl,dbUname,dbPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}

	
	public String Reg(User user){
		loadDriver(dbDriver);
		
		Connection con=getConnection();
		String result="Data entered successfully";
		String sql="insert into register(fname,mname) values(?,?)";
		PreparedStatement ps; 
		
		try {
			ps = con.prepareStatement(sql);
		ps.setString(1, user.getFname());
		ps.setString(2, user.getMname());
		
		
		ps.executeUpdate();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		result="Data not entered";
	}
		return result;
	}
	
	
	public String insert(User user){
		loadDriver(dbDriver);
		
		Connection con=getConnection();
		String result="Data entered successfully";
		String sql="insert into users(fname,mname,lname,address,dob,gender,marital,phone,email,qualification,institute,yog,pemp,pdes,cemp,cdes,totexp,skills) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement ps; 
		
		try {
			ps = con.prepareStatement(sql);
		ps.setString(1, user.getFname());
		ps.setString(2, user.getMname());
		ps.setString(3, user.getLname());
		ps.setString(4, user.getAddress());
		ps.setString(5, user.getDob());
		ps.setString(6, user.getGender());
		ps.setString(7, user.getMarital());
		ps.setString(8, user.getPhone());
		ps.setString(9, user.getEmail());
		ps.setString(10, user.getQualification());
		ps.setString(11, user.getInstitute());
		ps.setString(12, user.getYog());
		ps.setString(13, user.getPemp());
		ps.setString(14, user.getPdes());
		ps.setString(15, user.getCemp());
		ps.setString(16, user.getCdes());
		ps.setString(17, user.getTotexp());
		ps.setString(18, user.getSkills());

		
		
		
		ps.executeUpdate();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		result="Data not entered";
	}
		return result;
	}
	
	
	
	public String insertJob(User user){
		loadDriver(dbDriver);
		
		Connection con=getConnection();
		String result="Data entered successfully";
		String sql="insert into member(fname,mname,lname,address,dob,gender,marital,phone,email,qualification,institute) values(?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement ps; 
		
		try {
			ps = con.prepareStatement(sql);
		ps.setString(1, user.getFname());
		ps.setString(2, user.getMname());
		ps.setString(3, user.getLname());
		ps.setString(4, user.getAddress());
		ps.setString(5, user.getDob());
		ps.setString(6, user.getGender());
		ps.setString(7, user.getMarital());
		ps.setString(8, user.getPhone());
		ps.setString(9, user.getEmail());
		ps.setString(10, user.getQualification());
		ps.setString(11, user.getInstitute());
	
		
		
		
		ps.executeUpdate();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		result="Data not entered";
	}
		return result;
	}
	
	
	public User selectUser(int id) {
		User user = null;
		
		try (Connection connection = getConnection();
				
				PreparedStatement preparedStatement = connection.prepareStatement(SELECT_USER_BY_ID);) {
			preparedStatement.setInt(1, id);
			System.out.println(preparedStatement);
		
			ResultSet rs = preparedStatement.executeQuery();

			
			while (rs.next()) {
				String fname = rs.getString("fname");
				String mname = rs.getString("mname");
				String lname = rs.getString("lname");
				String address = rs.getString("address");
				String dob = rs.getString("dob");
				String gender = rs.getString("gender");
				String marital = rs.getString("marital");
				String phone = rs.getString("phone");
				String email = rs.getString("email");
				String qualification = rs.getString("qualification");
				String institute = rs.getString("institute");
				String yog = rs.getString("yog");
				String pemp = rs.getString("pemp");
				String pdes = rs.getString("pdes");
				String cemp = rs.getString("cemp");
				String cdes = rs.getString("cdes");
				String totexp = rs.getString("totexp");
				String skills = rs.getString("skills");
				user = new User(id,fname,mname,lname,address,dob,gender,marital,phone,email,qualification,institute,yog,pemp,pdes,cemp,cdes,totexp,skills);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return user;
	}
	

	public List<User> selectAllUsers() {

		
		List<User> users = new ArrayList<>();
		
		try (Connection connection = getConnection();

			
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_USERS);) {
			System.out.println(preparedStatement);
			
			ResultSet rs = preparedStatement.executeQuery();

			
			while (rs.next()) {
		
				String fname = rs.getString("fname");
				String mname = rs.getString("mname");
				String lname = rs.getString("lname");
				String address = rs.getString("address");
				String dob = rs.getString("dob");
				String gender = rs.getString("gender");
				String marital = rs.getString("marital");
				String phone = rs.getString("phone");
				String email = rs.getString("email");
				String qualification = rs.getString("qualification");
				String institute = rs.getString("institute");
				String yog = rs.getString("yog");
				String pemp = rs.getString("pemp");
				String pdes = rs.getString("pdes");
				String cemp = rs.getString("cemp");
				String cdes = rs.getString("cdes");
				String totexp = rs.getString("totexp");
				String skills = rs.getString("skills");
				users.add(new User(fname,mname,lname,address,dob,gender,marital,phone,email,qualification,institute,yog,pemp,pdes,cemp,cdes,totexp,skills));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}

	
public List<User> selectAllResumes() {

		
		List<User> resumes = new ArrayList<>();
		
		try (Connection connection = getConnection();

			
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_RESUMES);) {
			System.out.println(preparedStatement);
			
			ResultSet rs = preparedStatement.executeQuery();

			
			while (rs.next()) {
		
				String fname = rs.getString("fname");
				String mname = rs.getString("mname");
				String lname = rs.getString("lname");
				String address = rs.getString("address");
				String dob = rs.getString("dob");
				String gender = rs.getString("gender");
				String marital = rs.getString("marital");
				String phone = rs.getString("phone");
				String email = rs.getString("email");
				String qualification = rs.getString("qualification");
				String institute = rs.getString("institute");
				String yog = rs.getString("yog");
				String pemp = rs.getString("pemp");
				String pdes = rs.getString("pdes");
				String cemp = rs.getString("cemp");
				String cdes = rs.getString("cdes");
				String totexp = rs.getString("totexp");
				String skills = rs.getString("skills");
			
				resumes.add(new User(fname,mname,lname,address,dob,gender,marital,phone,email,qualification,institute,yog,pemp,pdes,cemp,cdes,totexp,skills));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return resumes;
	}	

	
	
	
	
	
	
public List<User> selectAllJobs() {

		
		List<User> jobs = new ArrayList<>();
		
		try (Connection connection = getConnection();

			
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_JOBS);) {
			System.out.println(preparedStatement);
			
			ResultSet rs = preparedStatement.executeQuery();

			
			while (rs.next()) {
		
				String fname = rs.getString("fname");
				String mname = rs.getString("mname");
				String lname = rs.getString("lname");
				String address = rs.getString("address");
				String dob = rs.getString("dob");
				String gender = rs.getString("gender");
				String marital = rs.getString("marital");
				String phone = rs.getString("phone");
				String email = rs.getString("email");
				String qualification = rs.getString("qualification");
				String institute = rs.getString("institute");
			
				jobs.add(new User(fname,mname,lname,address,dob,gender,marital,phone,email,qualification,institute));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return jobs;
	}


	public boolean deleteUser(int id) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(DELETE_USERS_SQL);) {
			statement.setInt(1, id);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updateUser(User user) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(UPDATE_USERS_SQL);) {
			System.out.println("updated USer:"+statement);
		
			statement.setString(1, user.getFname());
			statement.setString(2, user.getMname());
			statement.setString(3, user.getLname());
			statement.setString(4, user.getAddress());
			statement.setString(5, user.getDob());
			statement.setString(6, user.getGender());
			statement.setString(7, user.getMarital());
			statement.setString(8, user.getPhone());
			statement.setString(9, user.getEmail());
			statement.setString(10, user.getQualification());
			statement.setString(11, user.getInstitute());
			statement.setString(12, user.getYog());
			statement.setString(13, user.getPemp());
			statement.setString(14, user.getPdes());
			statement.setString(15, user.getCemp());
			statement.setString(16, user.getCdes());
			statement.setString(17, user.getTotexp());
			statement.setString(18, user.getSkills());

			

			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}

	private void printSQLException(SQLException ex) {
		for (Throwable e : ex) {
			if (e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("SQLState: " + ((SQLException) e).getSQLState());
				System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
				System.err.println("Message: " + e.getMessage());
				Throwable t = ex.getCause();
				while (t != null) {
					System.out.println("Cause: " + t);
					t = t.getCause();
				}
			}
		}
	}
	

}