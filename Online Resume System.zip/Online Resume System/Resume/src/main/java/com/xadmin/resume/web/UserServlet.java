package com.xadmin.resume.web;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xadmin.resume.dao.UserDao;
import com.xadmin.resume.bean.User;


@WebServlet("/")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDao userDAO;
	
	public void init() {
		userDAO = new UserDao();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			case "/new":
				showNewForm(request, response);
				break;
			case "/insert":
				insertUser(request, response);
				break;
			case "/delete":
				deleteUser(request, response);
				break;
			case "/edit":
				showEditForm(request, response);
				break;
			case "/update":
				updateUser(request, response);
				break;
			case "/admin":
				insertAdmin(request, response);
				break;
			case "/jobs":
				listJobs(request, response);
				break;
			case "/resumes":
				listResumes(request, response);
				break;
			case "/register":
				register(request, response);
				break;
			case "/logout":
				logout(request, response);
				break;
			case "/ulogin":
				login(request, response);
				break;
			case "/alogin":
				adlogin(request, response);
				break;
			default:
				listUser(request, response);
				break;
			}
		} catch (SQLException ex) {
			throw new ServletException(ex);
		}
	}

	
	private void register(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		String fname = request.getParameter("fname");
		String mname = request.getParameter("mname");
		User newUser = new User(fname,mname);
		userDAO.Reg(newUser);
		response.sendRedirect("User Login.jsp");
	}
	
	private void adlogin(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
	
		response.sendRedirect("Admin Login.jsp");
	}
	
	
	private void logout(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
	
		response.sendRedirect("Register.jsp");
	}
	
	private void login(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
	
		response.sendRedirect("User Login.jsp");
	}
	
	private void listUser(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<User> listUser = userDAO.selectAllUsers();
		request.setAttribute("listUser", listUser);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user-list.jsp");
		dispatcher.forward(request, response);
	}
	
	private void listJobs(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<User> listJobs = userDAO.selectAllJobs();
		request.setAttribute("listJobs", listJobs);
		RequestDispatcher dispatcher = request.getRequestDispatcher("users.jsp");
		dispatcher.forward(request, response);
	}
	
	private void listResumes(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<User> listResumes = userDAO.selectAllResumes();
		request.setAttribute("listResumes", listResumes);
		RequestDispatcher dispatcher = request.getRequestDispatcher("resumes.jsp");
		dispatcher.forward(request, response);
	}



	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("user-form.jsp");
		dispatcher.forward(request, response);
	}
	


	private void showEditForm(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		User existingUser = userDAO.selectUser(id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user-form.jsp");
		request.setAttribute("user", existingUser);
		dispatcher.forward(request, response);

	}

	private void insertUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		String fname = request.getParameter("fname");
		String mname = request.getParameter("mname");
		String lname = request.getParameter("lname");
		String address = request.getParameter("address");
		String dob = request.getParameter("dob");
		String gender = request.getParameter("gender");
		String marital = request.getParameter("marital");
		String phone = request.getParameter("phone");
		String email = request.getParameter("email");
		String qualification = request.getParameter("qualification");
		String institute = request.getParameter("institute");
		String yog = request.getParameter("yog");
		String pemp = request.getParameter("pemp");
		String pdes = request.getParameter("pdes");
		String cemp = request.getParameter("cemp");
		String cdes = request.getParameter("cdes");
		String totexp = request.getParameter("totexp");
		String skills = request.getParameter("skills");
		User newUser = new User(fname,mname,lname,address,dob,gender,marital,phone,email,qualification,institute,yog,pemp,pdes,cemp,cdes,totexp,skills);
		userDAO.insert(newUser);
		response.sendRedirect("list");
	}
	
	private void insertAdmin(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		String fname = request.getParameter("fname");
		String mname = request.getParameter("mname");
		String lname = request.getParameter("lname");
		String address = request.getParameter("address");
		String dob = request.getParameter("dob");
		String gender = request.getParameter("gender");
		String marital = request.getParameter("marital");
		String phone = request.getParameter("phone");
		String email = request.getParameter("email");
		String qualification = request.getParameter("qualification");
		String institute = request.getParameter("institute");
		
		User newUser = new User(fname,mname,lname,address,dob,gender,marital,phone,email,qualification,institute);
		userDAO.insertJob(newUser);
		response.sendRedirect("list");
	}

	private void updateUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {

		String fname = request.getParameter("fname");
		String mname = request.getParameter("mname");
		String lname = request.getParameter("lname");
		String address = request.getParameter("address");
		String dob = request.getParameter("dob");
		String gender = request.getParameter("gender");
		String marital = request.getParameter("marital");
		String phone = request.getParameter("phone");
		String email = request.getParameter("email");
		String qualification = request.getParameter("qualification");
		String institute = request.getParameter("institute");
		String yog = request.getParameter("yog");
		String pemp = request.getParameter("pemp");
		String pdes = request.getParameter("pdes");
		String cemp = request.getParameter("cemp");
		String cdes = request.getParameter("cdes");
		String totexp = request.getParameter("totexp");
		String skills = request.getParameter("skills");
		User book = new User(fname,mname,lname,address,dob,gender,marital,phone,email,qualification,institute,yog,pemp,pdes,cemp,cdes,totexp,skills );
		userDAO.updateUser(book);
		response.sendRedirect("list");
	}

	private void deleteUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		userDAO.deleteUser(id);
		response.sendRedirect("list");

	}

}